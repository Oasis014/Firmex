import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eje-alta',
  templateUrl: './eje-alta.component.html',
  styleUrls: ['./eje-alta.component.scss']
})
export class EjeAltaComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

