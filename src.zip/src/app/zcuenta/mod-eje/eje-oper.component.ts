import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eje-oper',
  templateUrl: './eje-oper.component.html',
  styleUrls: ['./eje-oper.component.scss']
})
export class EjeOperComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

