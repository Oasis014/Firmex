import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
@Component({
  selector: 'app-mod-eje',
  templateUrl: './mod-eje.component.html',
  styleUrls: ['./mod-eje.component.scss']
})
export class ModEjeComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}
