import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prospect-relM',
  templateUrl: './prospect-relM.component.html',
  styleUrls: ['./prospect-relM.component.scss']
})
export class ProspectRelMComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

