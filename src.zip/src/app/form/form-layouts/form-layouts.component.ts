import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-layouts',
  templateUrl: './form-layouts.component.html',
  styleUrls: ['./form-layouts.component.scss']
})
export class FormLayoutsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
