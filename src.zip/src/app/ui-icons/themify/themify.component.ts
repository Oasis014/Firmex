import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-themify',
  templateUrl: './themify.component.html',
  styleUrls: ['./themify.component.scss']
})
export class ThemifyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
