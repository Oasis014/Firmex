import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cose-credi',
  templateUrl: './cose-credi.component.html',
  styleUrls: ['./cose-credi.component.scss']
})
export class CoseCrediComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

