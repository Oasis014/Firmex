import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oper-credi',
  templateUrl: './oper-credi.component.html',
  styleUrls: ['./oper-credi.component.scss']
})
export class OperCrediComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

