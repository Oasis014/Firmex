import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oper nocredi',
  templateUrl: './oper-nocredi.component.html',
  styleUrls: ['./oper-nocredi.component.scss']
})
export class OperNocrediComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

