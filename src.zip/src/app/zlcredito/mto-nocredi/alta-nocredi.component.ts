import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alta-nocredi',
  templateUrl: './alta-nocredi.component.html',
  styleUrls: ['./alta-nocredi.component.scss']
})
export class AltaNocrediComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

