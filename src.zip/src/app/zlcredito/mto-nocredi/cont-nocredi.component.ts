import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cont nocredi',
  templateUrl: './cont-nocredi.component.html',
  styleUrls: ['./cont-nocredi.component.scss']
})
export class ContNocrediComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

