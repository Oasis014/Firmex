import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cose nocredi',
  templateUrl: './cose-nocredi.component.html',
  styleUrls: ['./cose-nocredi.component.scss']
})
export class CoseNocrediComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

