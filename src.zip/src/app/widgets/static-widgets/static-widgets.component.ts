import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-static-widgets',
  templateUrl: './static-widgets.component.html',
  styleUrls: ['./static-widgets.component.scss']
})
export class StaticWidgetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
