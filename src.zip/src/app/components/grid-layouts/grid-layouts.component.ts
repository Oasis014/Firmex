import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-layouts',
  templateUrl: './grid-layouts.component.html',
  styleUrls: ['./grid-layouts.component.scss']
})
export class GridLayoutsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
