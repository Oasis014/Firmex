import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error3',
  templateUrl: './error3.component.html',
  styleUrls: ['./error3.component.scss']
})
export class Error3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
