export interface Catalogos {
  catalogo_cve: number|string;
  desc_45: string;
}