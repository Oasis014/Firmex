import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-btnview',
    templateUrl: './btnview.component.html',
    styleUrls: ['./btnview.component.scss']
})

export class BtnViewComponent implements OnInit{
ngOnInit() {

   }

   ModF(router) { }
}
