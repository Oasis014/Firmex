import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-btnedit',
    templateUrl: './btnedit.component.html',
    styleUrls: ['./btnedit.component.scss']
})

export class BtnEditComponent implements OnInit{

        ngOnInit() {

           }
           }
