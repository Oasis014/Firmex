import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {
url = 'http://127.0.0.1/insert/';


  constructor(private http: HttpClient) { }
  mostrarTodos(){
    return this.http.get(`${this.url}mostrarTodos.php`);
  }
  agregar(usuario: any){
    return this.http.post(`${this.url}Ejemplo2.php`, JSON.stringify(usuario));
  }
  agregar2(usuario: any){
      return this.http.post(`${this.url}Ejemplo3.php`, JSON.stringify(usuario));
    }
  agregar3(usuario: any){
        return this.http.post(`${this.url}CuentaBancaria.php`, JSON.stringify(usuario));
      }
}
