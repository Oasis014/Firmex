import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { ToastrService } from 'ngx-toastr';
import { ClienteService } from '../cliente.service';
import {NgForm} from '@angular/forms';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-mod-moral',
  templateUrl: './mod-moral.component.html',
  styleUrls: ['./mod-moral.component.scss']
})
export class ModMoralComponent implements OnInit {


public isCollapsed = false;
public isCollapsed2 = true;
cliente = null as any;
economica = {
        Id: null,
        ActividadEconomica: null,
        ActividadDetallada: null,
        IngresoMensual: null,
        OtroIngresoMensual: null,
        GastosMensuales: null,
        FlujoEfectivo: null
}
cuenta = {
        Id: null,
        Consecutivo: null,
        NombreBank: null,
        BancoCtaBan: null,
        NumBan: null,
        ClaveInter: null
}
dom = {
        Id: null,
        Calle: null,
        NoEx: null,
        NoIn: null,
        CodPos: null,
        Colonia: null,
        Municipio: null,
        Estado: null,
        Pais: null,
        TipoDom: null
}
/*
general = {
    NumeroCLiente: null,
    sucursal: null,
    ApellidoPaterno: null,
    ApellidoMaterno: null,
    PrimerNombre: null,
    SegundoNombre: null,
    RazonSocial: null,
    ClavePromotor: null,
    EstatusCliente: null,
    FechaAlta: null,
    PersonalidadJuridica: null,
    RFC: null,
    Nacionalidad: null,
    EmailPersonal: null,
    EmailEmpresa: null,
    ParteRelacionada: null,
    GrupoConsejo: null,
    GrupoRiesgoComun: null,
    FechaNacimiento: null,
    Sexo: null,
    EstadoCivil: null,
    CURP: null,
    TipoIdentificacion: null,
    NumeroIdentificacion: null,
    ListaNegra: null,
    Profesion: null,
    NombreSociedad: null,
    FechaConstitucion: null,
    RepresentanteLegal: null,
    PresidenteConsejo: null,
    Consejero: null
  }*/

general = {
    Sucursal: null,
    ClavePromotor: null,
    NumeroCLiente: null,
    ApellidoPaterno: null,
    ApellidoMaterno: null,
    PrimerNombre: null,
    SegundoNombre: null,
    Nombre: null,
    EstatusCliente: null,
    FechaAlta: null,
    FechaNacimiento: null,
    PersonaJuridica: null,
    Sexo: null,
    EstadoCivil: null,
    CURP: null,
    RFC: null,
    TipoIdentificacion: null,
    NumeroIdentificacion: null,
    Nacionalidad: null,
    ListaNegra: null,
    Profesion: null,
    EmailPersonal: null,
    EmailEmpresa: null,
    ParteRelacionada: null,
    GrupoConsejo: null,
    GrupoRiesgoComun: null,
    TipoDomicilio: null,
    Calle: null,
    NumeroExterior: null,
    NumeroInterior: null,
    Codigo_postal: null,
    Colonia: null,
    Municipio: null,
    Estado: null,
    Pais: null,
    Latitud: null,
    Longitud: null,
    TipoTelefono: null,
    Telefono: null,
    Extension: null,
    ActividadEconomica: null,
    ActividadDetallada: null,
    IngresoMensual: null,
    OtroIngresoMensual: null,
    GastosMensuales: null,
    FlujoEfectivo: null,
    NombreCuentaBancariaCtaBan: null,
    BancoCtaBan: null,
    NumeroCuentaCtaBan: null,
    ClaveInterbancariaCtaBan: null,
    RedSocial: null,
    TipoRedSocial: null,
    InstitucionRefBan: null,
    AntiguedadRefBan: null,
    LimiteCreditoRefBan: null,
    SaldoCuentaRefBan: null,
    ApellidoPaternoRefCom: null,
    ApellidoMaternoRefCom: null,
    PrimerNombreRefCom: null,
    SegundoNombreRefCom: null,
    LimiteCreditoRefCom: null,
    SaldoCuenta: null,
    ApellidoPaternoRefPer: null,
    ApellidoMaternoRefPer: null,
    PrimerNombreRefPer: null,
    SegundoNombreRefPer: null,
    TipoRelacionRefPer: null,
    TelefonoRefPer: null,
  }

open() {this.router.navigate(['list-clienteM'], { relativeTo: this.route.parent }); }

  constructor(public toastr: ToastrService, private router: Router, private route: ActivatedRoute, private clienteService: ClienteService) { }

    Domicilio(){
          this.clienteService.agregar2(this.dom).subscribe(datos =>{
          });
        }

    General(){
              this.clienteService.agregar(this.general).subscribe(datos =>{
              });
            }

    Cuenta(){
                  this.clienteService.agregar3(this.cuenta).subscribe(datos =>{
                  });
                }


  ngOnInit() {
  }
  list() {this.router.navigate(['mto-fisica'], { relativeTo: this.route.parent }); }
  typeSuccess() {
        this.toastr.success('Modificado con Exito', 'Guardado');
    }
}
