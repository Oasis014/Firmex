import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prospect-estaM',
  templateUrl: './prospect-estaM.component.html',
  styleUrls: ['./prospect-estaM.component.scss']
})
export class ProspectEstaMComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

