import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prospect-benM',
  templateUrl: './prospect-benM.component.html',
  styleUrls: ['./prospect-benM.component.scss']
})
export class ProspectBenMComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

