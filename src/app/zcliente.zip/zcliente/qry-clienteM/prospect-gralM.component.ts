import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prospect-gralM',
  templateUrl: './prospect-gralM.component.html',
  styleUrls: ['./prospect-gralM.component.scss']
})
export class ProspectGralMComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

