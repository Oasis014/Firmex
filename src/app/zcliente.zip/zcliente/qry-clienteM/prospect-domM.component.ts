import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prospect-domM',
  templateUrl: './prospect-domM.component.html',
  styleUrls: ['./prospect-domM.component.scss']
})
export class ProspectDomMComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

