import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prospect-docM',
  templateUrl: './prospect-docM.component.html',
  styleUrls: ['./prospect-docM.component.scss']
})
export class ProspectDocMComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}

