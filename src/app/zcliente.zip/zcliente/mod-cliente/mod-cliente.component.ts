import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-mod-cliente',
  templateUrl: './mod-cliente.component.html',
  styleUrls: ['./mod-cliente.component.scss']
})
export class ModClienteComponent implements OnInit {
public isCollapsed = true;
public isCollapsed2 = true;

dato = {

    Sucursal: null,
    ClavePromotor: null,
    NumeroCLiente: null,
    ApellidoPaterno: null,
    ApellidoMaterno: null,
    PrimerNombre: null,
    SegundoNombre: null,
    Nombre: null,
    EstatusCliente: null,
    FechaAlta: null,
    FechaNacimiento: null,
    PersonaJuridica: null,
    Sexo: null,
    EstadoCivil: null,
    CURP: null,
    RFC: null,
    TipoIdentificacion: null,
    NumeroIdentificacion: null,
    Nacionalidad: null,
    ListaNegra: null,
    Profesion: null,
    EmailPersonal: null,
    EmailEmpresa: null,
    ParteRelacionada: null,
    GrupoConsejo: null,
    GrupoRiesgoComun: null,
    TipoDomicilio: null,
    Calle: null,
    NumeroExterior: null,
    NumeroInterior: null,
    Codigo_postal: null,
    Colonia: null,
    Municipio: null,
    Estado: null,
    Pais: null,
    Latitud: null,
    Longitud: null,
    TipoTelefono: null,
    Telefono: null,
    Extension: null,
    ActividadEconomica: null,
    ActividadDetallada: null,
    IngresoMensual: null,
    OtroIngresoMensual: null,
    GastosMensuales: null,
    FlujoEfectivo: null,
    NombreCuentaBancariaCtaBan: null,
    BancoCtaBan: null,
    NumeroCuentaCtaBan: null,
    ClaveInterbancariaCtaBan: null,
    RedSocial: null,
    TipoRedSocial: null,
    InstitucionRefBan: null,
    AntiguedadRefBan: null,
    LimiteCreditoRefBan: null,
    SaldoCuentaRefBan: null,
    ApellidoPaternoRefCom: null,
    ApellidoMaternoRefCom: null,
    PrimerNombreRefCom: null,
    SegundoNombreRefCom: null,
    LimiteCreditoRefCom: null,
    SaldoCuenta: null,
    ApellidoPaternoRefPer: null,
    ApellidoMaternoRefPer: null,
    PrimerNombreRefPer: null,
    SegundoNombreRefPer: null,
    TipoRelacionRefPer: null,
    TelefonoRefPer: null,


  }

open() {this.router.navigate(['list-clienteF'], { relativeTo: this.route.parent }); }

  constructor(public toastr: ToastrService, private router: Router,
                                        private route: ActivatedRoute) { }

  ngOnInit() {
  }
  list() {this.router.navigate(['mto-fisica'], { relativeTo: this.route.parent }); }
  typeSuccess() {
        this.toastr.success('Modificado con Exito', 'Guardado');
    }
}
